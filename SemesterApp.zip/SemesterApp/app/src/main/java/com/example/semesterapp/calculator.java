package com.example.semesterapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class calculator extends AppCompatActivity {
    private String plus, minus, gange, devidere;
    private Button plusbut, minusbut, gangebut, dividerebut;
    private EditText inputfield, inputFieldOne;
    private TextView outputfield;
    private int num1, num2, result_dividere;
    private float result_num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        plusbut = findViewById(R.id.Plusbut);
        minusbut = findViewById(R.id.Minusbut);
        gangebut = findViewById(R.id.gangeBut);
        dividerebut = findViewById(R.id.dividereBut);
        inputfield = findViewById(R.id.inputField);
        inputFieldOne = findViewById(R.id.inputFieldOne);
        outputfield = findViewById(R.id.outputField);


        plusbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 num1 = Integer.parseInt(inputfield.getText().toString());
                 num2 = Integer.parseInt(inputFieldOne.getText().toString());
                 result_num = num1 + num2;
                 outputfield.setText(String.valueOf(result_num));



            }
        });
        minusbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(inputfield.getText().toString());
                num2 = Integer.parseInt(inputFieldOne.getText().toString());
                result_num = num1 - num2;
                outputfield.setText(String.valueOf(result_num));
            }
        });
        gangebut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(inputfield.getText().toString());
                num2 = Integer.parseInt(inputFieldOne.getText().toString());
                result_num = num1 * num2;
                outputfield.setText(String.valueOf(result_num));
            }
        });
        dividerebut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(inputfield.getText().toString());
                num2 = Integer.parseInt(inputFieldOne.getText().toString());
                result_dividere = num1 / num2;
                outputfield.setText(String.valueOf(result_dividere));
            }
        });
    }
}
