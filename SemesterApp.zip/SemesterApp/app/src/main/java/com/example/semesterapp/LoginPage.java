package com.example.semesterapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {

    private EditText Username, Password;
    private Button LoginBut, backToMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared);

        LoginBut = findViewById(R.id.loginBut);
        backToMenu = findViewById(R.id.backTomenu);
        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);

        LoginBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValidateUser(Username.getText().toString(), Password.getText().toString());
            }
        });

        backToMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inten = new Intent(LoginPage.this, MainActivity.class);
                startActivity(inten);
            }
        });

    }

    public void ValidateUser(String Username, String Password) {

        if ((Username.equalsIgnoreCase("admin")) && (Password.equalsIgnoreCase("123"))) {
            Intent intent = new Intent(LoginPage.this, Shared.class);
            startActivity(intent);
        } else if (Username.equalsIgnoreCase("stef") && (Password.equalsIgnoreCase("123"))) {
            Intent intent2 = new Intent(LoginPage.this, Shared.class);
            startActivity(intent2);
        } else {
            Toast.makeText(LoginPage.this, "Mistake", Toast.LENGTH_SHORT).show();
        }

    }


}
