package com.example.semesterapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Shared extends AppCompatActivity {

    private TextView textView;
    private Button SaveTextBut, LokaltionBut;
    private EditText PlainText;

    public static final String Shared_Pref = "sharedpref";
    public static final String Text = "Text";

    private String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_preference);

        textView = findViewById(R.id.textView);
        SaveTextBut = findViewById(R.id.SaveTextBut);
        PlainText = findViewById(R.id.PlainText);
        LokaltionBut = findViewById(R.id.LokationBut);
        SaveTextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setText(PlainText.getText().toString());
                SafeRef();
            }
        });
        getRef();
        updateViews();


        LokaltionBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Shared.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void SafeRef() {
        SharedPreferences sharedPreferences = getSharedPreferences(Shared_Pref, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(Text, textView.getText().toString());
        editor.apply();

        Toast.makeText(this, "SAVED", Toast.LENGTH_SHORT).show();
    }

    public void getRef() {
        SharedPreferences sharedPreferences = getSharedPreferences(Shared_Pref, MODE_PRIVATE);
        text = sharedPreferences.getString(Text, " ");

    }

    public void updateViews() {
        textView.setText(text);
    }


}

