package com.example.semesterapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button mapBut, calcBut, LoginBut, WSSpring;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mapBut = findViewById(R.id.mapBut);
        calcBut = findViewById(R.id.calcBut);
        LoginBut = findViewById(R.id.Sharedbut);
        WSSpring = findViewById(R.id.WSSpring);

        mapBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });
        calcBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCalc = new Intent(MainActivity.this, calculator.class);
                startActivity(intentCalc);
            }
        });
        LoginBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intenLogin = new Intent(MainActivity.this, LoginPage.class);
                startActivity(intenLogin);
            }
        });
        WSSpring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentWSS = new Intent(MainActivity.this, Spring_WSS.class);
                startActivity(intentWSS);
            }
        });
    }
}
